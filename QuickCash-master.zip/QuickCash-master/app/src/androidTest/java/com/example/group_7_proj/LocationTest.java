package com.example.group_7_proj;

public class LocationTest {

    //Still not completetly sure how to test this function, but we're working on it.
}
