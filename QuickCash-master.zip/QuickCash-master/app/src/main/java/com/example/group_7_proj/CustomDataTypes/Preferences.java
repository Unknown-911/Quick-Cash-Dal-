package com.example.group_7_proj.CustomDataTypes;

public class Preferences {
}
