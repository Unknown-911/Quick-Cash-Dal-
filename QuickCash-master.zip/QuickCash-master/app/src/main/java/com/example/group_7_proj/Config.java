package com.example.group_7_proj;

public class Config {
    public static final String PAYPAL_CLIENT_ID = "AX9CqrPaDX2O9zRJ0RqORGlvS8IItlb--KY1Nl80et40dOZFRIdOJcvrW9DMe_fcga1gtlnGc5ojZZbP";
}
